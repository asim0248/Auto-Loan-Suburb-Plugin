<?php

defined('ABSPATH') || exit;

class ALAS_Admin {

    /**
     * Register admin hooks.
     */
    public function __construct() {
    add_action(
        'admin_menu',
        array($this, 'register_menu')
    );

    add_action(
        'admin_post_alas_add_suburb',
        array($this, 'save_suburb')
    );

    add_action(
        'admin_post_alas_delete_suburbs',
        array($this, 'delete_suburbs')
    );
}

    /**
     * States currently supported by the directory.
     */
    private function states() {
        return array(
            'NSW' => 'New South Wales',
            'VIC' => 'Victoria',
            'QLD' => 'Queensland',
        );
    }

    /**
     * Read a single text value safely from a request.
     */
    private function request_text($source, $key) {
        if (!isset($source[$key]) || !is_string($source[$key])) {
            return '';
        }

        return trim(
            sanitize_text_field(
                wp_unslash($source[$key])
            )
        );
    }

    /**
     * Restrict these screens and actions to administrators.
     */
    private function check_access() {
        if (!current_user_can('manage_options')) {
            wp_die(
                'You do not have permission to manage suburbs.',
                'Access Denied',
                array('response' => 403)
            );
        }
    }

    /**
     * Register the sidebar menu and submenus.
     */
    public function register_menu() {
        add_menu_page(
            'Auto Loan Suburbs',
            'Auto Loan Suburbs',
            'manage_options',
            'alas-suburbs',
            array($this, 'render_list'),
            'dashicons-location-alt',
            26
        );

        add_submenu_page(
            'alas-suburbs',
            'All Suburbs',
            'All Suburbs',
            'manage_options',
            'alas-suburbs',
            array($this, 'render_list')
        );

        add_submenu_page(
            'alas-suburbs',
            'Add New Suburb',
            'Add New',
            'manage_options',
            'alas-add-suburb',
            array($this, 'render_add_form')
        );
    }

    /**
     * Display the add-suburb form.
     *
     * Values are preserved when validation fails.
     */
    public function render_add_form($values = array(), $error = '') {
        $this->check_access();

        $values = wp_parse_args(
            $values,
            array(
                'suburb_name' => '',
                'state'       => '',
                'postcode'    => '',
                'is_active'   => 1,
            )
        );
        ?>
        <div class="wrap">
            <h1>Add New Suburb</h1>

            <p>
                Enter the suburb name only.
                The finance label will be added automatically
                when we build the frontend.
            </p>

            <?php if ($error !== '') : ?>
                <div class="notice notice-error">
                    <p><?php echo esc_html($error); ?></p>
                </div>
            <?php endif; ?>

            <form
                method="post"
                action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
            >
                <input
                    type="hidden"
                    name="action"
                    value="alas_add_suburb"
                >

                <?php wp_nonce_field('alas_add_suburb', 'alas_nonce'); ?>

                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <label for="alas-suburb-name">
                                    Suburb Name
                                </label>
                            </th>

                            <td>
                                <input
                                    type="text"
                                    id="alas-suburb-name"
                                    name="suburb_name"
                                    class="regular-text"
                                    maxlength="150"
                                    required
                                    value="<?php echo esc_attr($values['suburb_name']); ?>"
                                    placeholder="Example: Oxley Park"
                                >

                                <p class="description">
                                    Enter the suburb name only.
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="alas-state">
                                    State
                                </label>
                            </th>

                            <td>
                                <select
                                    id="alas-state"
                                    name="state"
                                    required
                                >
                                    <option value="">Select a state</option>

                                    <?php foreach ($this->states() as $code => $label) : ?>
                                        <option
                                            value="<?php echo esc_attr($code); ?>"
                                            <?php selected($values['state'], $code); ?>
                                        >
                                            <?php echo esc_html($label . ' (' . $code . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="alas-postcode">
                                    Postcode
                                </label>
                            </th>

                            <td>
                                <input
                                    type="text"
                                    id="alas-postcode"
                                    name="postcode"
                                    class="small-text"
                                    inputmode="numeric"
                                    pattern="[0-9]{4}"
                                    maxlength="4"
                                    value="<?php echo esc_attr($values['postcode']); ?>"
                                    placeholder="2760"
                                >

                                <p class="description">
                                    Optional. If entered, use exactly 4 digits.
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Status</th>

                            <td>
                                <label>
                                    <input
                                        type="checkbox"
                                        name="is_active"
                                        value="1"
                                        <?php checked((int) $values['is_active'], 1); ?>
                                    >
                                    Active
                                </label>

                                <p class="description">
                                    Only active suburbs will appear
                                    in the frontend directory.
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <?php submit_button('Save Suburb'); ?>

                <a
                    href="<?php echo esc_url(admin_url('admin.php?page=alas-suburbs')); ?>"
                >
                    Back to All Suburbs
                </a>
            </form>
        </div>
        <?php
    }

    /**
     * Display an error and allow the user to correct their form.
     */
    private function form_error($values, $message) {
        // admin-post.php does not render the normal admin page shell.
        global $title;
        $title = 'Add New Suburb';

        require_once ABSPATH . 'wp-admin/admin-header.php';

        $this->render_add_form($values, $message);

        require_once ABSPATH . 'wp-admin/admin-footer.php';

        exit;
    }

    /**
     * Validate and save a new suburb.
     */
    public function save_suburb() {
        $this->check_access();

        if (
            !isset($_SERVER['REQUEST_METHOD']) ||
            $_SERVER['REQUEST_METHOD'] !== 'POST'
        ) {
            wp_die(
                'This action requires a form submission.',
                'Invalid Request',
                array('response' => 405)
            );
        }

        check_admin_referer('alas_add_suburb', 'alas_nonce');

        $values = array(
            'suburb_name' => $this->request_text($_POST, 'suburb_name'),
            'state'       => strtoupper(
                $this->request_text($_POST, 'state')
            ),
            'postcode'    => $this->request_text($_POST, 'postcode'),
            'is_active'   => (
                $this->request_text($_POST, 'is_active') === '1'
            ) ? 1 : 0,
        );

        // Normalize repeated spaces in suburb names.
        $values['suburb_name'] = preg_replace(
            '/\s+/u',
            ' ',
            $values['suburb_name']
        );

        if (empty($values['suburb_name'])) {
            $this->form_error(
                $values,
                'Please enter a suburb name.'
            );
        }

        $name_length = function_exists('mb_strlen')
            ? mb_strlen($values['suburb_name'], 'UTF-8')
            : strlen($values['suburb_name']);

        if ($name_length > 150) {
            $this->form_error(
                $values,
                'The suburb name must be 150 characters or fewer.'
            );
        }

        $states = $this->states();

        if (!isset($states[$values['state']])) {
            $this->form_error(
                $values,
                'Please select a valid state.'
            );
        }

        if (
            $values['postcode'] !== '' &&
            !preg_match('/^[0-9]{4}$/', $values['postcode'])
        ) {
            $this->form_error(
                $values,
                'The postcode must contain exactly 4 digits.'
            );
        }

        global $wpdb;

        $table = ALAS_Database::table_name();

        // Check for an existing location.
        $existing_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM {$table}
                 WHERE suburb_name = %s
                   AND state = %s
                   AND postcode = %s
                 LIMIT 1",
                $values['suburb_name'],
                $values['state'],
                $values['postcode']
            )
        );

        if ($existing_id) {
            $this->form_error(
                $values,
                'This suburb, state and postcode combination already exists.'
            );
        }

        $now = current_time('mysql');

        $result = $wpdb->insert(
            $table,
            array(
                'suburb_name' => $values['suburb_name'],
                'state'       => $values['state'],
                'postcode'    => $values['postcode'],
                'is_active'   => $values['is_active'],
                'created_at'  => $now,
                'updated_at'  => $now,
            ),
            array(
                '%s',
                '%s',
                '%s',
                '%d',
                '%s',
                '%s',
            )
        );

        if ($result === false) {
            $this->form_error(
                $values,
                'The suburb could not be saved. Check whether it already exists, then try again.'
            );
        }

        // Redirect after saving to prevent duplicate submissions on refresh.
        wp_safe_redirect(
            add_query_arg(
                array(
                    'page'         => 'alas-suburbs',
                    'alas_message' => 'added',
                ),
                admin_url('admin.php')
            )
        );

        exit;
    }

    /**
 * Delete a single suburb or selected suburbs.
 */
public function delete_suburbs() {
    $this->check_access();

    if (
        !isset($_SERVER['REQUEST_METHOD']) ||
        $_SERVER['REQUEST_METHOD'] !== 'POST'
    ) {
        wp_die(
            'This action requires a form submission.',
            'Invalid Request',
            array('response' => 405)
        );
    }

    check_admin_referer(
        'alas_delete_suburbs',
        'alas_delete_nonce'
    );

    $ids = array();

    /*
     * A row's Delete button takes priority.
     * Checked boxes are ignored when deleting a single row.
     */
    $single_id = $this->request_text($_POST, 'single_id');

    if ($single_id !== '') {
        $raw_ids = array($single_id);
    } else {
        $raw_ids = (
            isset($_POST['suburb_ids']) &&
            is_array($_POST['suburb_ids'])
        ) ? wp_unslash($_POST['suburb_ids']) : array();
    }

    // The admin list contains at most 50 records per page.
    if (count($raw_ids) > 50) {
        wp_die('Please select no more than 50 suburbs at a time.');
    }

    foreach ($raw_ids as $raw_id) {
        if (
            !is_scalar($raw_id) ||
            !ctype_digit((string) $raw_id) ||
            (int) $raw_id < 1
        ) {
            wp_die('An invalid suburb ID was submitted.');
        }

        $ids[] = (int) $raw_id;
    }

    $ids = array_values(array_unique($ids));

    if (empty($ids)) {
        wp_die(
            'Please select at least one suburb.',
            'No Suburbs Selected',
            array('back_link' => true)
        );
    }

    global $wpdb;

    $table = ALAS_Database::table_name();

    // Create one numeric placeholder for each selected ID.
    $placeholders = implode(
        ', ',
        array_fill(0, count($ids), '%d')
    );

    $deleted = $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE id IN ({$placeholders})",
            $ids
        )
    );

    // Preserve the user's list filters and page.
    $state = strtoupper(
        $this->request_text($_POST, 'return_state')
    );

    $states = $this->states();

    if (!isset($states[$state])) {
        $state = '';
    }

    $redirect_args = array(
        'page'  => 'alas-suburbs',
        's'     => $this->request_text($_POST, 'return_search'),
        'state' => $state,
        'paged' => max(
            1,
            absint(
                $this->request_text($_POST, 'return_page')
            )
        ),
    );

    if ($deleted === false) {
        $redirect_args['alas_message'] = 'delete_failed';
    } else {
        $redirect_args['alas_message'] = 'deleted';
        $redirect_args['deleted_count'] = (int) $deleted;
    }

    wp_safe_redirect(
        add_query_arg(
            $redirect_args,
            admin_url('admin.php')
        )
    );

    exit;
}

    /**
 * Display records with search, pagination and delete controls.
 */
public function render_list() {
    $this->check_access();

    global $wpdb;

    $table = ALAS_Database::table_name();
    $states = $this->states();

    $search = $this->request_text($_GET, 's');
    $state = strtoupper(
        $this->request_text($_GET, 'state')
    );

    if (!isset($states[$state])) {
        $state = '';
    }

    $current_page = max(
        1,
        absint($this->request_text($_GET, 'paged'))
    );

    $per_page = 50;

    $where = 'WHERE 1 = %d';
    $params = array(1);

    if ($state !== '') {
        $where .= ' AND state = %s';
        $params[] = $state;
    }

    if ($search !== '') {
        $like = '%' . $wpdb->esc_like($search) . '%';

        $where .= ' AND (suburb_name LIKE %s OR postcode LIKE %s)';
        $params[] = $like;
        $params[] = $like;
    }

    $total = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} {$where}",
            $params
        )
    );

    $count_error = $wpdb->last_error;

    $total_pages = max(
        1,
        (int) ceil($total / $per_page)
    );

    $current_page = min($current_page, $total_pages);
    $offset = ($current_page - 1) * $per_page;

    $list_params = array_merge(
        $params,
        array($per_page, $offset)
    );

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id, suburb_name, state, postcode, is_active
             FROM {$table}
             {$where}
             ORDER BY suburb_name ASC, id ASC
             LIMIT %d OFFSET %d",
            $list_params
        )
    );

    $database_error = $count_error !== '' ||
        $wpdb->last_error !== '';

    $base_url = add_query_arg(
        array(
            'page'  => 'alas-suburbs',
            's'     => $search,
            'state' => $state,
        ),
        admin_url('admin.php')
    );

    $message = $this->request_text($_GET, 'alas_message');
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">All Suburbs</h1>

        <a
            class="page-title-action"
            href="<?php echo esc_url(admin_url('admin.php?page=alas-add-suburb')); ?>"
        >
            Add New
        </a>

        <hr class="wp-header-end">

        <?php if ($message === 'added') : ?>
            <div class="notice notice-success is-dismissible">
                <p>Suburb added successfully.</p>
            </div>
        <?php elseif ($message === 'deleted') : ?>
            <div class="notice notice-success is-dismissible">
                <p>
                    <?php
                    echo esc_html(
                        sprintf(
                            '%d suburb(s) deleted.',
                            absint(
                                $this->request_text(
                                    $_GET,
                                    'deleted_count'
                                )
                            )
                        )
                    );
                    ?>
                </p>
            </div>
        <?php elseif ($message === 'delete_failed') : ?>
            <div class="notice notice-error">
                <p>Delete failed. Please try again.</p>
            </div>
        <?php endif; ?>

        <?php if ($database_error) : ?>
            <div class="notice notice-error">
                <p>
                    Records could not be loaded.
                    Please check the database setup.
                </p>
            </div>
        <?php endif; ?>

        <!-- Search uses its own separate GET form. -->
        <form
            method="get"
            action="<?php echo esc_url(admin_url('admin.php')); ?>"
        >
            <input type="hidden" name="page" value="alas-suburbs">

            <p>
                <label class="screen-reader-text" for="alas-search">
                    Search suburbs
                </label>

                <input
                    type="search"
                    id="alas-search"
                    name="s"
                    value="<?php echo esc_attr($search); ?>"
                    placeholder="Suburb or postcode"
                >

                <label class="screen-reader-text" for="alas-filter-state">
                    Filter by state
                </label>

                <select id="alas-filter-state" name="state">
                    <option value="">All States</option>

                    <?php foreach ($states as $code => $label) : ?>
                        <option
                            value="<?php echo esc_attr($code); ?>"
                            <?php selected($state, $code); ?>
                        >
                            <?php echo esc_html($code); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="button">Filter</button>

                <a
                    class="button"
                    href="<?php echo esc_url(admin_url('admin.php?page=alas-suburbs')); ?>"
                >
                    Reset
                </a>
            </p>
        </form>

        <p>
            <strong>
                <?php echo esc_html(number_format_i18n($total)); ?>
            </strong>
            matching suburbs
        </p>

        <!-- Delete controls use a separate POST form. -->
        <form
            id="alas-delete-form"
            method="post"
            action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
        >
            <input
                type="hidden"
                name="action"
                value="alas_delete_suburbs"
            >

            <?php
            wp_nonce_field(
                'alas_delete_suburbs',
                'alas_delete_nonce'
            );
            ?>

            <input
                type="hidden"
                name="return_search"
                value="<?php echo esc_attr($search); ?>"
            >

            <input
                type="hidden"
                name="return_state"
                value="<?php echo esc_attr($state); ?>"
            >

            <input
                type="hidden"
                name="return_page"
                value="<?php echo esc_attr($current_page); ?>"
            >

            <p>
                <button
                    type="submit"
                    id="alas-delete-selected"
                    class="button"
                    disabled
                >
                    Delete Selected
                </button>

                <span id="alas-selection-count" aria-live="polite">
                    0 selected
                </span>
            </p>

            <p class="description">
                Select All selects only the records on this page.
                Deletion is permanent.
            </p>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <td class="manage-column column-cb check-column">
                            <label
                                class="screen-reader-text"
                                for="alas-select-all"
                            >
                                Select all suburbs on this page
                            </label>

                            <input
                                type="checkbox"
                                id="alas-select-all"
                            >
                        </td>

                        <th scope="col">ID</th>
                        <th scope="col">Suburb Name</th>
                        <th scope="col">State</th>
                        <th scope="col">Postcode</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!empty($rows)) : ?>
                        <?php foreach ($rows as $row) : ?>
                            <tr>
                                <th scope="row" class="check-column">
                                    <label
                                        class="screen-reader-text"
                                        for="alas-suburb-<?php echo esc_attr($row->id); ?>"
                                    >
                                        <?php
                                        echo esc_html(
                                            'Select ' . $row->suburb_name
                                        );
                                        ?>
                                    </label>

                                    <input
                                        type="checkbox"
                                        class="alas-row-checkbox"
                                        id="alas-suburb-<?php echo esc_attr($row->id); ?>"
                                        name="suburb_ids[]"
                                        value="<?php echo esc_attr($row->id); ?>"
                                    >
                                </th>

                                <td>
                                    <?php echo esc_html($row->id); ?>
                                </td>

                                <td>
                                    <strong>
                                        <?php echo esc_html($row->suburb_name); ?>
                                    </strong>
                                </td>

                                <td>
                                    <?php echo esc_html($row->state); ?>
                                </td>

                                <td>
                                    <?php
                                    echo esc_html(
                                        $row->postcode !== ''
                                            ? $row->postcode
                                            : '—'
                                    );
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    echo (int) $row->is_active === 1
                                        ? 'Active'
                                        : 'Inactive';
                                    ?>
                                </td>

                                <td>
                                    <button
                                        type="submit"
                                        name="single_id"
                                        value="<?php echo esc_attr($row->id); ?>"
                                        class="button button-small"
                                        data-suburb-name="<?php echo esc_attr($row->suburb_name); ?>"
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="7">No suburbs found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </form>

        <div class="tablenav bottom">
            <div class="tablenav-pages">
                <span class="displaying-num">
                    <?php
                    echo esc_html(
                        sprintf(
                            'Page %d of %d',
                            $current_page,
                            $total_pages
                        )
                    );
                    ?>
                </span>

                <?php if ($current_page > 1) : ?>
                    <a
                        class="button"
                        href="<?php echo esc_url(add_query_arg('paged', $current_page - 1, $base_url)); ?>"
                    >
                        Previous
                    </a>
                <?php endif; ?>

                <?php if ($current_page < $total_pages) : ?>
                    <a
                        class="button"
                        href="<?php echo esc_url(add_query_arg('paged', $current_page + 1, $base_url)); ?>"
                    >
                        Next
                    </a>
                <?php endif; ?>
            </div>
            <br class="clear">
        </div>
    </div>

    <script>
    (function () {
        const form = document.getElementById('alas-delete-form');

        if (!form) {
            return;
        }

        const selectAll = document.getElementById('alas-select-all');
        const deleteSelected = document.getElementById('alas-delete-selected');
        const counter = document.getElementById('alas-selection-count');

        const checkboxes = Array.from(
            form.querySelectorAll('.alas-row-checkbox')
        );

        function updateSelection() {
            const count = checkboxes.filter(
                checkbox => checkbox.checked
            ).length;

            counter.textContent = count + ' selected';
            deleteSelected.disabled = count === 0;

            selectAll.disabled = checkboxes.length === 0;

            selectAll.checked =
                checkboxes.length > 0 &&
                count === checkboxes.length;

            selectAll.indeterminate =
                count > 0 &&
                count < checkboxes.length;
        }

        selectAll.addEventListener('change', function () {
            checkboxes.forEach(function (checkbox) {
                checkbox.checked = selectAll.checked;
            });

            updateSelection();
        });

        checkboxes.forEach(function (checkbox) {
            checkbox.addEventListener('change', updateSelection);
        });

        form.addEventListener('submit', function (event) {
            const button = event.submitter;

            // Prevent unintended submissions without an explicit button.
            if (!button) {
                event.preventDefault();
                return;
            }

            let message;

            if (button.name === 'single_id') {
                const name = button.dataset.suburbName || 'this suburb';

                message =
                    'Permanently delete "' + name + '"?';
            } else {
                const count = checkboxes.filter(
                    checkbox => checkbox.checked
                ).length;

                if (count === 0) {
                    event.preventDefault();
                    alert('Please select at least one suburb.');
                    return;
                }

                message =
                    'Permanently delete ' + count +
                    ' selected suburb(s)?';
            }

            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });

        updateSelection();
    }());
    </script>
    <?php
}
}