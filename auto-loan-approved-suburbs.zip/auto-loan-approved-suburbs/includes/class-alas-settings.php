<?php

defined('ABSPATH') || exit;

class ALAS_Settings {

    public function __construct() {
        add_action(
            'admin_menu',
            array($this, 'register_menu'),
            30
        );

        add_action(
            'admin_init',
            array($this, 'register_settings')
        );
    }

    public function register_menu() {
        add_submenu_page(
            'alas-suburbs',
            'Suburbs Settings',
            'Settings',
            'manage_options',
            'alas-settings',
            array($this, 'render_page')
        );
    }

    public function register_settings() {
        register_setting('alas_settings_group', 'alas_label', array(
            'sanitize_callback' => static function ($value) {
                return in_array($value, array('Car Finance', 'Car Loans', 'Mixed'), true) ? $value : 'Car Finance';
            }
        ));
        register_setting(
            'alas_settings_group',
            'alas_popup_id',
            array(
                'type'              => 'integer',
                'default'           => 0,
                'sanitize_callback' => array($this, 'validate_popup_id'),
            )
        );
    }

    public function validate_popup_id($value) {
        $previous = absint(get_option('alas_popup_id', 0));

        if (!is_scalar($value)) {
            add_settings_error(
                'alas_popup_id',
                'alas_invalid_popup',
                'Please enter a valid numeric Popup ID.'
            );

            return $previous;
        }

        $value = trim((string) $value);

        // Empty or zero disables the popup integration.
        if ($value === '' || $value === '0') {
            return 0;
        }

        if (!ctype_digit($value) || (int) $value < 1) {
            add_settings_error(
                'alas_popup_id',
                'alas_invalid_popup',
                'Please enter a positive numeric Popup ID.'
            );

            return $previous;
        }

        $popup_id = (int) $value;
        $popup = get_post($popup_id);

        if (
            !$popup ||
            $popup->post_type !== 'popup' ||
            $popup->post_status !== 'publish'
        ) {
            add_settings_error(
                'alas_popup_id',
                'alas_popup_not_found',
                'This ID does not belong to a published Popup Maker popup. Publish your popup first, then enter its ID.'
            );

            return $previous;
        }

        return $popup_id;
    }

    public function render_page() {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to manage these settings.');
        }

        $popup_id = absint(get_option('alas_popup_id', 0));
        ?>
        <div class="wrap">
            <h1>Suburbs Settings</h1>

            <?php settings_errors(); ?>

            <form method="post" action="options.php">
                <?php settings_fields('alas_settings_group'); ?>

                <p><label>Suburb card label <select name="alas_label">
                <?php foreach (array('Car Finance','Car Loans','Mixed') as $choice) : ?>
                    <option <?php selected(get_option('alas_label','Car Finance'), $choice); ?>><?php echo esc_html($choice); ?></option>
                <?php endforeach; ?></select></label></p>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">
                            <label for="alas-popup-id">
                                Popup Maker ID
                            </label>
                        </th>

                        <td>
                            <input
                                type="number"
                                id="alas-popup-id"
                                name="alas_popup_id"
                                min="0"
                                step="1"
                                class="regular-text"
                                value="<?php echo esc_attr($popup_id); ?>"
                            >

                            <p class="description">
                                Enter the published popup's numeric ID.
                                Example: enter 125, not popmake-125.
                            </p>

                            <p class="description">
                                Leave this as 0 until your popup is ready.
                            </p>

                            <p class="description">
                                The popup must be available on the page
                                containing the suburbs directory.
                            </p>
                        </td>
                    </tr>
                </table>

                <?php submit_button('Save Settings'); ?>
            </form>
        </div>
        <?php
    }
}