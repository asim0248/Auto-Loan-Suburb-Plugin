<?php

defined('ABSPATH') || exit;

class ALAS_Shortcode {

    public function __construct() {
        add_shortcode(
            'alas_suburbs',
            array($this, 'render')
        );
    }

    public function render($atts = array()) {
        /*
         * File modification times prevent old CSS/JS from
         * remaining cached after plugin updates.
         */
        $css_path = ALAS_PLUGIN_PATH . 'assets/css/frontend.css';
        $js_path  = ALAS_PLUGIN_PATH . 'assets/js/frontend.js';

        wp_enqueue_style(
            'alas-frontend',
            ALAS_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            file_exists($css_path)
                ? (string) filemtime($css_path)
                : ALAS_VERSION
        );

        wp_enqueue_script(
            'alas-frontend',
            ALAS_PLUGIN_URL . 'assets/js/frontend.js',
            array(),
            file_exists($js_path)
                ? (string) filemtime($js_path)
                : ALAS_VERSION,
            true
        );

        $states = array(
            'NSW' => 'New South Wales',
            'VIC' => 'Victoria',
            'QLD' => 'Queensland',
        );

        $uid = wp_unique_id('alas-directory-');

        global $wpdb;
        $table = ALAS_Database::table_name();
        $rows = $wpdb->get_results("SELECT suburb_name, state, postcode FROM {$table} WHERE is_active = 1 ORDER BY suburb_name, postcode", ARRAY_A);
        $groups = array_fill_keys(array_keys($states), array());
        foreach ((array) $rows as $row) {
            if (isset($groups[$row['state']])) {
                $groups[$row['state']][] = $row;
            }
        }

        ob_start();

        /*
         * Shortcodes can render after wp_head.
         * Print this stylesheet here if it was not already printed.
         */
        if (!wp_style_is('alas-frontend', 'done')) {
            wp_print_styles(array('alas-frontend'));
        }

        include ALAS_PLUGIN_PATH . 'templates/suburbs-directory.php';

        return ob_get_clean();
    }
}