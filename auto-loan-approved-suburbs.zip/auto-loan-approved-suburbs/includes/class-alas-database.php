<?php

defined('ABSPATH') || exit;

class ALAS_Database {

    /**
     * Get the table name with the actual WordPress prefix.
     */
    public static function table_name() {
        global $wpdb;

        return $wpdb->prefix . 'alas_suburbs';
    }

    /**
     * Create or update the suburbs table.
     *
     * @return true|WP_Error
     */
    public static function install() {
        global $wpdb;

        $table_name = self::table_name();
        $charset_collate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            suburb_name varchar(150) NOT NULL,
            state varchar(3) NOT NULL,
            postcode varchar(4) NOT NULL DEFAULT '',
            is_active tinyint(1) unsigned NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY suburb_location (suburb_name, state, postcode),
            KEY state_active_name (state, is_active, suburb_name)
        ) {$charset_collate};";

        // WordPress compares the desired structure with the existing table.
        dbDelta($sql);

        // Capture any schema creation/update error before another query runs.
        $schema_error = $wpdb->last_error;

        if (!empty($schema_error)) {
            return new WP_Error(
                'alas_database_schema_error',
                'The suburbs database table could not be created or updated. Please check the server error log and database permissions.'
            );
        }

        // Confirm that the table exists.
        $existing_table = $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $wpdb->esc_like($table_name)
            )
        );

        if ($existing_table !== $table_name) {
            return new WP_Error(
                'alas_database_table_missing',
                'The suburbs database table was not found after installation. Please check your database permissions.'
            );
        }

        // Save the schema version only after successful setup.
        update_option('alas_db_version', ALAS_DB_VERSION);

        return true;
    }
}