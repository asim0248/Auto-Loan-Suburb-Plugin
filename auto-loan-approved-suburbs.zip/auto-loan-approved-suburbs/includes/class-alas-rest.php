<?php

defined('ABSPATH') || exit;

class ALAS_REST {

    public function __construct() {
        add_action(
            'rest_api_init',
            array($this, 'register_routes')
        );
    }

    /**
     * Register the public, read-only suburbs endpoint.
     */
    public function register_routes() {
        register_rest_route(
            'alas/v1',
            '/suburbs',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array($this, 'get_suburbs'),
                'permission_callback' => '__return_true',

                'args' => array(
                    'state' => array(
                        'type'     => 'string',
                        'required' => true,
                        'enum'     => array('NSW', 'VIC', 'QLD'),
                    ),

                    'page' => array(
                        'type'    => 'integer',
                        'default' => 1,
                        'minimum' => 1,
                        'maximum' => 100000,
                    ),

                    'search' => array(
                        'type'              => 'string',
                        'default'           => '',
                        'maxLength'         => 150,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );
    }

    /**
     * Return a page of active suburbs.
     */
    public function get_suburbs($request) {
        global $wpdb;

        $table = ALAS_Database::table_name();

        $state = (string) $request->get_param('state');
        $page = (int) $request->get_param('page');
        $search = trim(
            (string) $request->get_param('search')
        );

        // Controlled by the server, not by visitors.
        $per_page = 100;
        $offset = ($page - 1) * $per_page;

        $where = 'WHERE is_active = %d AND state = %s';
        $params = array(1, $state);

        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';

            $where .= ' AND (
                suburb_name LIKE %s
                OR postcode LIKE %s
            )';

            $params[] = $like;
            $params[] = $like;
        }

        // Count all matching records in the selected state.
        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*)
                 FROM {$table}
                 {$where}",
                $params
            )
        );

        if ($wpdb->last_error !== '') {
            return new WP_Error(
                'alas_query_failed',
                'Suburbs could not be loaded. Please try again.',
                array('status' => 500)
            );
        }

        $total = (int) $total;

        $query_params = array_merge(
            $params,
            array($per_page, $offset)
        );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, suburb_name, state, postcode
                 FROM {$table}
                 {$where}
                 ORDER BY suburb_name ASC, id ASC
                 LIMIT %d OFFSET %d",
                $query_params
            ),
            ARRAY_A
        );

        if ($wpdb->last_error !== '') {
            return new WP_Error(
                'alas_query_failed',
                'Suburbs could not be loaded. Please try again.',
                array('status' => 500)
            );
        }

        $items = array();

        foreach ($rows as $row) {
            $items[] = array(
                'id'          => (int) $row['id'],
                'suburb_name' => $row['suburb_name'],
                'state'       => $row['state'],
                'postcode'    => $row['postcode'],

                'label' => alas_suburb_label($row),
            );
        }

        $response = new WP_REST_Response(
            array(
                'items'       => $items,
                'state'       => $state,
                'search'      => $search,
                'page'        => $page,
                'per_page'    => $per_page,
                'total'       => $total,
                'total_pages' => (int) ceil($total / $per_page),
                'has_more'    => ($offset + $per_page) < $total,
            ),
            200
        );

        // Keep results fresh while we build and test the directory.
        $response->header(
            'Cache-Control',
            'no-store, max-age=0'
        );

        return $response;
    }
}