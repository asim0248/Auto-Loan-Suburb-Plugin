<?php

defined('ABSPATH') || exit;

class ALAS_Importer {

    const MAX_ROWS = 1000;
    const MAX_BYTES = 1048576; // 1 MB.

    public function __construct() {
        add_action(
            'admin_menu',
            array($this, 'register_menu'),
            20
        );

        add_action(
            'admin_post_alas_import_csv',
            array($this, 'import_csv')
        );
    }

    /**
     * Add Import CSV under the existing plugin menu.
     */
    public function register_menu() {
        add_submenu_page(
            'alas-suburbs',
            'Import Suburbs',
            'Import CSV',
            'manage_options',
            'alas-import-suburbs',
            array($this, 'render_page')
        );
    }

    private function check_access() {
        if (!current_user_can('manage_options')) {
            wp_die(
                'You do not have permission to import suburbs.',
                'Access Denied',
                array('response' => 403)
            );
        }
    }

    /**
     * Store a short-lived report for this administrator.
     */
    private function finish($report) {
        $token = wp_generate_uuid4();

        $key = 'alas_import_' . get_current_user_id() . '_' . $token;

        set_transient($key, $report, 10 * MINUTE_IN_SECONDS);

        wp_safe_redirect(
            add_query_arg(
                array(
                    'page'   => 'alas-import-suburbs',
                    'report' => $token,
                ),
                admin_url('admin.php')
            )
        );

        exit;
    }

    private function fail($message) {
        $this->finish(
            array('error' => $message)
        );
    }

    /**
     * Import screen and results.
     */
    public function render_page() {
        $this->check_access();

        $report = false;

        if (
            isset($_GET['report']) &&
            is_string($_GET['report'])
        ) {
            $token = sanitize_text_field(
                wp_unslash($_GET['report'])
            );

            if (preg_match('/^[a-f0-9-]{36}$/', $token)) {
                $key = 'alas_import_' .
                    get_current_user_id() .
                    '_' .
                    $token;

                $report = get_transient($key);
            }
        }
        ?>
        <div class="wrap">
            <h1>Import Suburbs from CSV</h1>

            <?php if (is_array($report)) : ?>

                <?php if (isset($report['error'])) : ?>
                    <div class="notice notice-error">
                        <p>
                            <?php echo esc_html($report['error']); ?>
                        </p>
                    </div>
                <?php else : ?>
                    <div class="notice notice-info">
                        <p>
                            <strong>Import completed.</strong>
                        </p>

                        <p>
                            <?php
                            echo esc_html(
                                sprintf(
                                    'Processed: %d | Added: %d | Duplicates: %d | Invalid: %d | Database failures: %d',
                                    $report['processed'],
                                    $report['added'],
                                    $report['duplicates'],
                                    $report['invalid'],
                                    $report['failed']
                                )
                            );
                            ?>
                        </p>
                    </div>

                    <?php if (!empty($report['issues'])) : ?>
                        <div class="notice notice-warning">
                            <p>
                                <strong>
                                    First 20 row issues:
                                </strong>
                            </p>

                            <ul>
                                <?php foreach ($report['issues'] as $issue) : ?>
                                    <li>
                                        <?php echo esc_html($issue); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                <?php endif; ?>

            <?php endif; ?>

            <p>
                Required column headers:
                <code>suburb_name,state,postcode</code>
            </p>

            <p>
                Save the file as UTF-8, comma-delimited CSV.
                Maximum 1,000 data rows and 1 MB per upload.
            </p>

            <p>
                Supported states: NSW, VIC and QLD.
                Postcode values may be blank.
            </p>

            <p>
                Existing records will be skipped.
                Valid new records will be imported as active.
            </p>

            <form
                method="post"
                enctype="multipart/form-data"
                action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
            >
                <input
                    type="hidden"
                    name="action"
                    value="alas_import_csv"
                >

                <?php
                wp_nonce_field(
                    'alas_import_csv',
                    'alas_import_nonce'
                );
                ?>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">
                            <label for="alas-csv-file">
                                CSV File
                            </label>
                        </th>

                        <td>
                            <input
                                type="file"
                                id="alas-csv-file"
                                name="alas_csv"
                                accept=".csv,text/csv"
                                required
                            >
                        </td>
                    </tr>
                </table>

                <?php submit_button('Import Suburbs'); ?>
            </form>

            <p>
                <a
                    href="<?php echo esc_url(admin_url('admin.php?page=alas-suburbs')); ?>"
                >
                    View All Suburbs
                </a>
            </p>
        </div>
        <?php
    }

    /**
     * Read a CSV record using standard CSV escaping.
     */
    private function read_row($handle) {
        return fgetcsv($handle, 0, ',', '"', '');
    }

    /**
     * Process the uploaded CSV.
     */
    public function import_csv() {
        $this->check_access();

        if (
            !isset($_SERVER['REQUEST_METHOD']) ||
            $_SERVER['REQUEST_METHOD'] !== 'POST'
        ) {
            wp_die(
                'Please submit the import form.',
                'Invalid Request',
                array('response' => 405)
            );
        }

        check_admin_referer(
            'alas_import_csv',
            'alas_import_nonce'
        );

        if (
            !isset($_FILES['alas_csv']) ||
            !is_array($_FILES['alas_csv'])
        ) {
            $this->fail('Please select a CSV file.');
        }

        $file = $_FILES['alas_csv'];

        foreach (array('error', 'name', 'tmp_name', 'size') as $key) {
            if (
                !isset($file[$key]) ||
                !is_scalar($file[$key])
            ) {
                $this->fail('The uploaded file is invalid.');
            }
        }

        if ((int) $file['error'] !== UPLOAD_ERR_OK) {
            $this->fail(
                'The upload failed. Check the file size and try again.'
            );
        }

        $extension = strtolower(
            pathinfo((string) $file['name'], PATHINFO_EXTENSION)
        );

        if ($extension !== 'csv') {
            $this->fail('Please upload a .csv file.');
        }

        $temporary_path = (string) $file['tmp_name'];

        if (!is_uploaded_file($temporary_path)) {
            $this->fail('The uploaded file could not be verified.');
        }

        $actual_size = filesize($temporary_path);

        if (
            $actual_size === false ||
            $actual_size === 0 ||
            $actual_size > self::MAX_BYTES
        ) {
            $this->fail(
                'Upload a non-empty CSV file no larger than 1 MB.'
            );
        }

        $handle = fopen($temporary_path, 'r');

        if ($handle === false) {
            $this->fail('The CSV file could not be opened.');
        }

        $headers = $this->read_row($handle);

        if (!is_array($headers)) {
            fclose($handle);
            $this->fail('The CSV header row is missing.');
        }

        // Remove the UTF-8 BOM commonly added by Excel.
        $headers[0] = preg_replace(
            '/^\xEF\xBB\xBF/',
            '',
            (string) $headers[0]
        );

        $headers = array_map(
            static function ($header) {
                return strtolower(trim((string) $header));
            },
            $headers
        );

        $required = array(
            'suburb_name',
            'state',
            'postcode',
        );

        if (
            count($headers) !== 3 ||
            count(array_unique($headers)) !== 3 ||
            array_diff($required, $headers)
        ) {
            fclose($handle);

            $this->fail(
                'Use exactly these three CSV headers: suburb_name,state,postcode. Make sure the delimiter is a comma.'
            );
        }

        /*
         * Read the bounded file before inserting anything.
         * An oversized row count therefore causes no partial import.
         */
        $records = array();
        $record_number = 1;

        while (($row = $this->read_row($handle)) !== false) {
            $record_number++;

            $has_content = false;

            foreach ($row as $cell) {
                if (trim((string) $cell) !== '') {
                    $has_content = true;
                    break;
                }
            }

            if (!$has_content) {
                continue;
            }

            $records[] = array(
                'number' => $record_number,
                'cells'  => $row,
            );

            if (count($records) > self::MAX_ROWS) {
                fclose($handle);

                $this->fail(
                    'This file has more than 1,000 data rows. Split it into smaller CSV files. Nothing from this upload was imported.'
                );
            }
        }

        $read_completed = feof($handle);

        fclose($handle);

        if (!$read_completed) {
            $this->fail(
                'The CSV could not be read completely. Nothing was imported.'
            );
        }

        if (empty($records)) {
            $this->fail('The CSV contains no data rows.');
        }

        global $wpdb;

        $table = ALAS_Database::table_name();

        $report = array(
            'processed'  => 0,
            'added'      => 0,
            'duplicates' => 0,
            'invalid'    => 0,
            'failed'     => 0,
            'issues'     => array(),
        );

        $allowed_states = array('NSW', 'VIC', 'QLD');

        foreach ($records as $record) {
            $report['processed']++;

            $row = $record['cells'];
            $number = $record['number'];
            $error = '';

            if (count($row) !== count($headers)) {
                $error = 'Expected exactly three columns.';
            } else {
                $data = array_combine($headers, $row);

                // Reject broken encodings rather than saving damaged names.
                foreach ($data as $value) {
                    if (preg_match('//u', (string) $value) !== 1) {
                        $error = 'Invalid text encoding. Save as CSV UTF-8.';
                        break;
                    }
                }

                if ($error === '') {
                    $name = trim(
                        sanitize_text_field(
                            (string) $data['suburb_name']
                        )
                    );

                    $name = preg_replace('/\s+/u', ' ', $name);

                    $state = strtoupper(
                        trim((string) $data['state'])
                    );

                    $postcode = trim(
                        (string) $data['postcode']
                    );

                    $length = function_exists('mb_strlen')
                        ? mb_strlen($name, 'UTF-8')
                        : strlen($name);

                    if ($name === '' || $length > 150) {
                        $error = 'Suburb name must contain 1–150 characters.';
                    } elseif (!in_array($state, $allowed_states, true)) {
                        $error = 'State must be NSW, VIC or QLD.';
                    } elseif (
                        $postcode !== '' &&
                        !preg_match('/^[0-9]{4}$/', $postcode)
                    ) {
                        $error = 'Postcode must be blank or exactly four digits.';
                    }
                }
            }

            if ($error !== '') {
                $report['invalid']++;

                if (count($report['issues']) < 20) {
                    $report['issues'][] =
                        'CSV record ' . $number . ': ' . $error;
                }

                continue;
            }

            $existing_id = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$table}
                     WHERE suburb_name = %s
                       AND state = %s
                       AND postcode = %s
                     LIMIT 1",
                    $name,
                    $state,
                    $postcode
                )
            );

            if ($existing_id) {
                $report['duplicates']++;
                continue;
            }

            $now = current_time('mysql');

            $inserted = $wpdb->insert(
                $table,
                array(
                    'suburb_name' => $name,
                    'state'       => $state,
                    'postcode'    => $postcode,
                    'is_active'   => 1,
                    'created_at'  => $now,
                    'updated_at'  => $now,
                ),
                array('%s', '%s', '%s', '%d', '%s', '%s')
            );

            if ($inserted === false) {
                $report['failed']++;

                if (count($report['issues']) < 20) {
                    $report['issues'][] =
                        'CSV record ' . $number .
                        ': Database insert failed. Check whether the record already exists.';
                }

                continue;
            }

            $report['added']++;
        }

        /*
         * The upload stays in PHP's temporary upload location.
         * It is not added to the Media Library or a public folder.
         * PHP removes it at the end of the request.
         */
        $this->finish($report);
    }
}