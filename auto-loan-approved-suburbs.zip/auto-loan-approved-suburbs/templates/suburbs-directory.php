<?php defined('ABSPATH') || exit; ?>
<section class="alas-directory" aria-label="Vehicle finance by suburb" data-popup="<?php echo esc_attr(absint(get_option('alas_popup_id'))); ?>">
<h2>Find Vehicle Finance in Your Suburb</h2>
<p>Choose your state and suburb, then select Next to start your enquiry.</p>
<div class="alas-states" aria-label="Choose a state">
<?php foreach ($states as $code => $name) : ?>
<button type="button" data-state="<?php echo esc_attr($code); ?>" aria-pressed="<?php echo $code === 'NSW' ? 'true' : 'false'; ?>"><?php echo esc_html($name); ?></button>
<?php endforeach; ?>
</div>
<?php foreach ($states as $code => $name) : ?>
<div class="alas-panel" data-region="<?php echo esc_attr($code); ?>">
<h3><?php echo esc_html($name); ?></h3>
<label>Search suburb or postcode <input type="search" autocomplete="off"></label>
<div class="alas-controls"><button type="button" data-dir="-1" aria-label="Scroll left">←</button><button type="button" data-dir="1" aria-label="Scroll right">→</button></div>
<ul tabindex="0" aria-label="<?php echo esc_attr($name . ' suburbs'); ?>">
<?php foreach ($groups[$code] as $row) : ?>
<li><button type="button" aria-pressed="false" data-name="<?php echo esc_attr($row['suburb_name']); ?>" data-postcode="<?php echo esc_attr($row['postcode']); ?>"><?php echo esc_html(alas_suburb_label($row)); ?><small><?php echo esc_html(trim($code . ' ' . $row['postcode'])); ?></small></button></li>
<?php endforeach; ?>
</ul>
<p class="alas-empty" <?php if ($groups[$code]) echo 'hidden'; ?>>No matching suburbs.</p>
</div>
<?php endforeach; ?>
<p class="alas-status" role="status"></p><button type="button" class="alas-next" hidden>Next →</button>
<noscript>Enable JavaScript to select a suburb and open the enquiry form.</noscript>
</section>
