<?php
/**
 * Plugin Name: Auto Loan Approved Suburbs
 * Description: A searchable suburb directory with state tabs and enquiry integration.
 * Version: 1.0.0
 * Author: Asim Saeed
 * Text Domain: alas-suburbs
 */

defined('ABSPATH') || exit;

// Plugin version.
define('ALAS_VERSION', '1.0.0');

// Database structure version.
define('ALAS_DB_VERSION', '1.0.0');

// Plugin folder path on the server.
define('ALAS_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Plugin folder URL for CSS and JavaScript.
define('ALAS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load the database class.
require_once ALAS_PLUGIN_PATH . 'includes/class-alas-database.php';

/**
 * Runs when the plugin is activated.
 */
function alas_activate_plugin() {
    $result = ALAS_Database::install();

    if (is_wp_error($result)) {
        wp_die(
            esc_html($result->get_error_message()),
            'Suburbs Plugin Activation Error',
            array('back_link' => true)
        );
    }
}

register_activation_hook(__FILE__, 'alas_activate_plugin');

/**
 * Update the database structure when its version changes.
 */
function alas_maybe_upgrade_database() {
    $installed_version = get_option('alas_db_version', '');

    if (ALAS_DB_VERSION === $installed_version) {
        return;
    }

    $result = ALAS_Database::install();

    if (is_wp_error($result)) {
        add_action('admin_notices', 'alas_database_error_notice');
    }
}

add_action('admin_init', 'alas_maybe_upgrade_database');

/**
 * Show a generic database setup error to administrators.
 */
function alas_database_error_notice() {
    if (!current_user_can('manage_options')) {
        return;
    }
    ?>
    <div class="notice notice-error">
        <p>
            <strong>Auto Loan Approved Suburbs:</strong>
            Database setup could not be completed.
            Please check your database permissions and server error log.
        </p>
    </div>
    <?php
}

/**
 * Load the admin screens, form handlers and CSV importer.
 */
if (is_admin()) {
    require_once ALAS_PLUGIN_PATH . 'includes/class-alas-admin.php';
    require_once ALAS_PLUGIN_PATH . 'includes/class-alas-importer.php';
    require_once ALAS_PLUGIN_PATH . 'includes/class-alas-settings.php';

    new ALAS_Admin();
    new ALAS_Importer();
    new ALAS_Settings();
}
/**
 * Load the public API.
 */
require_once ALAS_PLUGIN_PATH . 'includes/class-alas-rest.php';

$GLOBALS['alas_rest_instance'] = new ALAS_REST();

/**
 * Load the frontend shortcode.
 */
require_once ALAS_PLUGIN_PATH . 'includes/class-alas-shortcode.php';

new ALAS_Shortcode();

function alas_suburb_label($row) {
    $label = get_option('alas_label', 'Car Finance');
    if ($label === 'Mixed') {
        $choices = array('Car Finance', 'Car Loans', 'Truck Loans', 'Asset Finance');
        $hash = md5($row['state'] . '|' . $row['suburb_name'] . '|' . $row['postcode']);
        $label = $choices[hexdec(substr($hash, 0, 2)) % count($choices)];
    }
    return $label . ' in ' . $row['suburb_name'];
}
