(function () {
    function init(root) {
        if (root.dataset.ready) return;
        root.dataset.ready = '1';
        const panels = [...root.querySelectorAll('[data-region]')];
        const states = [...root.querySelectorAll('[data-state]')];
        const next = root.querySelector('.alas-next');
        const status = root.querySelector('.alas-status');
        let choice;
        function clear() {
            if (choice) choice.setAttribute('aria-pressed', 'false');
            choice = null;
            status.textContent = '';
            next.hidden = true;
        }
        function switchState(state) {
            clear();
            states.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.state === state)));
            panels.forEach(panel => { panel.hidden = panel.dataset.region !== state; });
        }
        switchState(states[0].dataset.state);
        root.addEventListener('input', event => {
            if (!event.target.matches('input[type=search]')) return;
            clear();
            const panel = event.target.closest('[data-region]');
            const needle = event.target.value.trim().toLowerCase();
            let count = 0;
            panel.querySelectorAll('[data-name]').forEach(button => {
                const show = (button.dataset.name + ' ' + button.dataset.postcode).toLowerCase().includes(needle);
                button.parentElement.hidden = !show;
                if (show) count++;
            });
            panel.querySelector('.alas-empty').hidden = count > 0;
            panel.querySelector('ul').scrollLeft = 0;
        });
        root.addEventListener('click', event => {
            const button = event.target.closest('button');
            if (!button) return;
            if (button.dataset.state) return switchState(button.dataset.state);
            if (button.dataset.dir) {
                const list = button.closest('[data-region]').querySelector('ul');
                list.scrollBy({left: list.clientWidth * Number(button.dataset.dir)});
            }
            if (button.dataset.name) {
                clear();
                choice = button;
                choice.setAttribute('aria-pressed', 'true');
                status.textContent = 'Selected: ' + choice.dataset.name + ', ' + choice.closest('[data-region]').dataset.region;
                next.hidden = false;
            }
            if (button !== next || !choice) return;
            const id = Number(root.dataset.popup);
            const popup = document.getElementById('pum-' + id) || document.getElementById('popmake-' + id);
            if (!id || !popup || typeof window.PUM?.open !== 'function') {
                status.textContent = 'The enquiry popup is unavailable. Please use the main enquiry form.';
                return;
            }
            const values = {selected_suburb: choice.dataset.name, selected_state: choice.closest('[data-region]').dataset.region};
            function fill() {
                Object.entries(values).forEach(([name, value]) => {
                    popup.querySelectorAll('form input[name="' + name + '"]').forEach(input => {
                        input.value = value;
                        input.dispatchEvent(new Event('input', {bubbles:true}));
                        input.dispatchEvent(new Event('change', {bubbles:true}));
                    });
                });
            }
            fill();
            if (window.jQuery) window.jQuery(popup).off('pumAfterOpen.alas').one('pumAfterOpen.alas', fill);
            window.PUM.open(id);
        });
    }
    function start() { document.querySelectorAll('.alas-directory').forEach(init); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
})();
